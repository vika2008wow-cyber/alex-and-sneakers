import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Crown, a as User, b as Battery, c as Store, d as Rocket, f as Pointer, g as Flame, h as Gem, i as Volume2, l as Star, m as HeartPulse, n as X, o as Trophy, p as Medal, r as VolumeX, t as Zap, u as RotateCcw, v as ChartNoAxesColumn, y as Bot } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CiR6rGED.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ctx = null;
var master = null;
var sfx = null;
var noise = null;
var muted = false;
function ensure() {
	if (typeof window === "undefined") return null;
	if (!ctx) {
		ctx = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: "interactive" });
		master = ctx.createGain();
		sfx = ctx.createGain();
		sfx.gain.value = .7;
		master.gain.value = muted ? 0 : .9;
		sfx.connect(master);
		master.connect(ctx.destination);
		const n = ctx.createBuffer(1, ctx.sampleRate * .4, ctx.sampleRate);
		const d = n.getChannelData(0);
		for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
		noise = n;
	}
	if (ctx.state === "suspended") ctx.resume();
	return ctx;
}
function unlockAudio() {
	ensure();
}
function setMuted(next) {
	muted = next;
	if (master && ctx) master.gain.setTargetAtTime(next ? 0 : .9, ctx.currentTime, .02);
}
function envGain(c, peak, dur) {
	const g = c.createGain();
	const t = c.currentTime;
	g.gain.setValueAtTime(1e-4, t);
	g.gain.exponentialRampToValueAtTime(peak, t + .008);
	g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
	g.connect(sfx);
	return g;
}
function playTap(crit = false) {
	const c = ensure();
	if (!c || muted || !sfx || !noise) return;
	const t = c.currentTime;
	const osc = c.createOscillator();
	const g = envGain(c, crit ? .22 : .12, crit ? .18 : .09);
	osc.type = "triangle";
	const f = (crit ? 240 : 170) + Math.random() * 50;
	osc.frequency.setValueAtTime(f, t);
	osc.frequency.exponentialRampToValueAtTime(crit ? 90 : 70, t + .1);
	osc.connect(g);
	osc.start(t);
	osc.stop(t + .14);
	const src = c.createBufferSource();
	src.buffer = noise;
	src.playbackRate.value = 3.2 + Math.random() * .8;
	const ng = envGain(c, crit ? .08 : .035, .06);
	const bp = c.createBiquadFilter();
	bp.type = "bandpass";
	bp.frequency.value = crit ? 1800 : 900;
	src.connect(bp).connect(ng);
	src.start(t);
	src.stop(t + .07);
}
function playEmpty() {
	const c = ensure();
	if (!c || muted || !sfx) return;
	const t = c.currentTime;
	const osc = c.createOscillator();
	const g = envGain(c, .06, .08);
	osc.type = "square";
	osc.frequency.setValueAtTime(90, t);
	osc.frequency.exponentialRampToValueAtTime(50, t + .08);
	osc.connect(g);
	osc.start(t);
	osc.stop(t + .09);
}
function playBuy() {
	const c = ensure();
	if (!c || muted || !sfx) return;
	const t = c.currentTime;
	[
		523,
		659,
		784
	].forEach((f, i) => {
		const osc = c.createOscillator();
		const g = c.createGain();
		const when = t + i * .05;
		osc.type = "sine";
		osc.frequency.value = f;
		g.gain.setValueAtTime(1e-4, when);
		g.gain.exponentialRampToValueAtTime(.09, when + .01);
		g.gain.exponentialRampToValueAtTime(1e-4, when + .18);
		osc.connect(g).connect(sfx);
		osc.start(when);
		osc.stop(when + .2);
	});
}
function playReward() {
	const c = ensure();
	if (!c || muted || !sfx) return;
	const t = c.currentTime;
	[
		392,
		523,
		659,
		784,
		1046
	].forEach((f, i) => {
		const osc = c.createOscillator();
		const g = c.createGain();
		const when = t + i * .07;
		osc.type = "triangle";
		osc.frequency.value = f;
		g.gain.setValueAtTime(1e-4, when);
		g.gain.exponentialRampToValueAtTime(.11, when + .015);
		g.gain.exponentialRampToValueAtTime(1e-4, when + .28);
		osc.connect(g).connect(sfx);
		osc.start(when);
		osc.stop(when + .3);
	});
}
var SAVE_KEY = "sashka_snickers_save_v1";
var DEFAULT_STATE = {
	version: 1,
	bars: 0,
	totalBars: 0,
	taps: 0,
	perTap: 1,
	perSec: 0,
	clickLevel: 1,
	autoLevel: 0,
	energyLevel: 0,
	regenLevel: 0,
	luckLevel: 0,
	multiplier: 1,
	energy: 600,
	maxEnergy: 600,
	energyRegen: 3,
	claimedRewards: [],
	achievements: [],
	goldenSnickers: false,
	name: "Сашка",
	startedAt: 0,
	muted: false,
	lastTick: 0,
	seenIntro: false
};
var SHOP = [
	{
		id: "click",
		name: "Сила тапа",
		desc: "+1 сникерс за нажатие",
		icon: "pointer",
		cost: (s) => Math.floor(18 * Math.pow(1.55, s.clickLevel - 1)),
		owned: (s) => s.clickLevel,
		buy: (s) => ({
			clickLevel: s.clickLevel + 1,
			perTap: s.perTap + 1
		})
	},
	{
		id: "auto",
		name: "Работники склада",
		desc: "+1 сникерс в секунду, пока Сашка спит",
		icon: "bot",
		cost: (s) => Math.floor(55 * Math.pow(1.62, s.autoLevel)),
		owned: (s) => s.autoLevel,
		buy: (s) => ({
			autoLevel: s.autoLevel + 1,
			perSec: s.perSec + 1
		})
	},
	{
		id: "boost",
		name: "Мегабуст",
		desc: "Удвоить силу тапа навсегда",
		icon: "zap",
		cost: (s) => Math.floor(420 * s.multiplier * (1 + Math.log2(s.multiplier) * 1.4)),
		owned: (s) => Math.round(Math.log2(s.multiplier)),
		buy: (s) => ({ multiplier: s.multiplier * 2 })
	},
	{
		id: "energy",
		name: "Запас сил",
		desc: "+200 к запасу энергии",
		icon: "battery",
		cost: (s) => Math.floor(80 * Math.pow(1.7, s.energyLevel)),
		owned: (s) => s.energyLevel,
		buy: (s) => ({
			energyLevel: s.energyLevel + 1,
			maxEnergy: s.maxEnergy + 200,
			energy: s.energy + 200
		})
	},
	{
		id: "regen",
		name: "Сон силача",
		desc: "+1 энергия в секунду",
		icon: "heart",
		cost: (s) => Math.floor(90 * Math.pow(1.68, s.regenLevel)),
		owned: (s) => s.regenLevel,
		buy: (s) => ({
			regenLevel: s.regenLevel + 1,
			energyRegen: s.energyRegen + 1
		})
	},
	{
		id: "luck",
		name: "Золотой укус",
		desc: "+4% шанс критического тапа ×10",
		icon: "clover",
		cost: (s) => Math.floor(220 * Math.pow(1.75, s.luckLevel)),
		owned: (s) => s.luckLevel,
		buy: (s) => ({ luckLevel: s.luckLevel + 1 })
	}
];
var REWARDS = [
	{
		id: "r100",
		at: 100,
		icon: "medal",
		title: "Бронзовый батончик",
		text: "+500 сникерсов на склад.",
		apply: (s) => ({
			bars: s.bars + 500,
			totalBars: s.totalBars + 500
		})
	},
	{
		id: "r1k",
		at: 1e3,
		icon: "medal",
		title: "Серебряный батончик",
		text: "Работники склада: +2 сникерса в секунду.",
		apply: (s) => ({
			perSec: s.perSec + 2,
			autoLevel: s.autoLevel + 2
		})
	},
	{
		id: "r10k",
		at: 1e4,
		icon: "trophy",
		title: "Золотой батончик",
		text: "Множитель тапа ×3 и +5 000 сникерсов.",
		apply: (s) => ({
			multiplier: s.multiplier * 3,
			bars: s.bars + 5e3,
			totalBars: s.totalBars + 5e3
		})
	},
	{
		id: "r100k",
		at: 1e5,
		icon: "gem",
		title: "Золотой сникерс",
		text: "Автоклик +20/сек и сила тапа ×5.",
		apply: (s) => ({
			goldenSnickers: true,
			perSec: s.perSec + 20,
			autoLevel: s.autoLevel + 20,
			multiplier: s.multiplier * 5
		})
	},
	{
		id: "r500k",
		at: 5e5,
		icon: "crown",
		title: "Король склада",
		text: "+100 000 сникерсов бонусом.",
		apply: (s) => ({
			bars: s.bars + 1e5,
			totalBars: s.totalBars + 1e5
		})
	},
	{
		id: "r1m",
		at: 1e6,
		icon: "rocket",
		title: "Миллионер склада",
		text: "Нереально. Множитель тапа ×10.",
		apply: (s) => ({ multiplier: s.multiplier * 10 })
	}
];
var ACHIEVEMENTS = [
	{
		id: "first",
		icon: "pointer",
		title: "Первый тап",
		desc: "Разбудить Сашку",
		cond: (s) => s.taps >= 1
	},
	{
		id: "tap100",
		icon: "flame",
		title: "Разогрев",
		desc: "100 тапов",
		cond: (s) => s.taps >= 100
	},
	{
		id: "bar1k",
		icon: "zap",
		title: "Тысяча",
		desc: "1 000 сникерсов за всё время",
		cond: (s) => s.totalBars >= 1e3
	},
	{
		id: "bar10k",
		icon: "flame",
		title: "Палета",
		desc: "10 000 сникерсов за всё время",
		cond: (s) => s.totalBars >= 1e4
	},
	{
		id: "bar100k",
		icon: "gem",
		title: "Фура",
		desc: "100 000 сникерсов за всё время",
		cond: (s) => s.totalBars >= 1e5
	},
	{
		id: "golden",
		icon: "trophy",
		title: "Золотой сникерс",
		desc: "Получить легендарную награду",
		cond: (s) => s.goldenSnickers
	},
	{
		id: "shop",
		icon: "store",
		title: "Закупщик",
		desc: "Сила тапа 5 уровня",
		cond: (s) => s.clickLevel >= 5
	},
	{
		id: "auto",
		icon: "bot",
		title: "Автоматизация",
		desc: "5 работников на складе",
		cond: (s) => s.autoLevel >= 5
	},
	{
		id: "king",
		icon: "crown",
		title: "Хозяин склада",
		desc: "1 000 000 сникерсов за всё время",
		cond: (s) => s.totalBars >= 1e6
	}
];
var BOT_NAMES = [
	"БорисСклад",
	"КатяТап",
	"ВоваГолд",
	"НастяПалета",
	"ОлегФура",
	"ЛенаКарамель",
	"МаксНуга",
	"ИгорьАрахис",
	"ЮляЛампа",
	"ПашаПоток",
	"ДашаШоколад",
	"КириллСейф"
];
function clamp(n, a, b) {
	return Math.max(a, Math.min(b, n));
}
function migrate(raw) {
	const merged = {
		...DEFAULT_STATE,
		...raw,
		version: 1
	};
	merged.bars = Math.max(0, merged.bars || 0);
	merged.totalBars = Math.max(merged.bars, merged.totalBars || 0);
	merged.energy = clamp(merged.energy || DEFAULT_STATE.energy, 0, merged.maxEnergy || DEFAULT_STATE.maxEnergy);
	merged.claimedRewards = Array.isArray(merged.claimedRewards) ? merged.claimedRewards : [];
	merged.achievements = Array.isArray(merged.achievements) ? merged.achievements : [];
	merged.name = (merged.name || "Сашка").slice(0, 18);
	return merged;
}
function loadRaw() {
	if (typeof window === "undefined") return { ...DEFAULT_STATE };
	try {
		const raw = localStorage.getItem(SAVE_KEY);
		if (!raw) return { ...DEFAULT_STATE };
		return migrate(JSON.parse(raw));
	} catch {
		return { ...DEFAULT_STATE };
	}
}
function saveRaw(s) {
	if (typeof window === "undefined") return;
	const payload = {
		version: 1,
		bars: s.bars,
		totalBars: s.totalBars,
		taps: s.taps,
		perTap: s.perTap,
		perSec: s.perSec,
		clickLevel: s.clickLevel,
		autoLevel: s.autoLevel,
		energyLevel: s.energyLevel,
		regenLevel: s.regenLevel,
		luckLevel: s.luckLevel,
		multiplier: s.multiplier,
		energy: s.energy,
		maxEnergy: s.maxEnergy,
		energyRegen: s.energyRegen,
		claimedRewards: s.claimedRewards,
		achievements: s.achievements,
		goldenSnickers: s.goldenSnickers,
		name: s.name,
		startedAt: s.startedAt,
		muted: s.muted,
		lastTick: s.lastTick,
		seenIntro: s.seenIntro
	};
	try {
		localStorage.setItem(SAVE_KEY, JSON.stringify(payload));
	} catch {}
}
var saveTimer = null;
function scheduleSave(s) {
	if (saveTimer) return;
	saveTimer = setTimeout(() => {
		saveTimer = null;
		saveRaw(s);
	}, 400);
}
function unlockAchievements(s) {
	const have = new Set(s.achievements);
	let changed = false;
	for (const a of ACHIEVEMENTS) if (!have.has(a.id) && a.cond(s)) {
		have.add(a.id);
		changed = true;
	}
	return changed ? [...have] : s.achievements;
}
function nextReward(s) {
	for (const r of REWARDS) if (s.totalBars >= r.at && !s.claimedRewards.includes(r.id)) return {
		id: r.id,
		icon: r.icon,
		title: r.title,
		text: r.text
	};
	return null;
}
var useGame = create((set, get) => ({
	...DEFAULT_STATE,
	hydrated: false,
	tab: null,
	pendingReward: null,
	combo: 0,
	lastTapAt: 0,
	awakeUntil: 0,
	trauma: 0,
	energyFlash: 0,
	offlineGain: 0,
	hydrate: () => {
		if (get().hydrated) return;
		const loaded = loadRaw();
		const now = Date.now();
		if (get().seenIntro && !loaded.seenIntro) {
			const startedAt = get().startedAt || now;
			set({
				hydrated: true,
				startedAt,
				lastTick: now
			});
			saveRaw({
				...get(),
				seenIntro: true,
				startedAt,
				lastTick: now
			});
			return;
		}
		let offlineGain = 0;
		let energy = loaded.energy;
		let bars = loaded.bars;
		let totalBars = loaded.totalBars;
		if (loaded.lastTick > 0 && loaded.seenIntro) {
			const elapsed = clamp((now - loaded.lastTick) / 1e3, 0, 28800);
			offlineGain = loaded.perSec * elapsed;
			bars += offlineGain;
			totalBars += offlineGain;
			energy = clamp(loaded.energy + loaded.energyRegen * elapsed, 0, loaded.maxEnergy);
		}
		const startedAt = loaded.startedAt || now;
		const next = {
			...loaded,
			bars,
			totalBars,
			energy,
			startedAt,
			lastTick: now
		};
		next.achievements = unlockAchievements(next);
		set({
			...next,
			hydrated: true,
			pendingReward: nextReward(next),
			offlineGain,
			combo: 0,
			trauma: 0
		});
		saveRaw(next);
	},
	persist: () => {
		saveRaw({
			...get(),
			lastTick: Date.now()
		});
	},
	tick: (dt, now) => {
		const s = get();
		if (!s.hydrated || !s.seenIntro) return;
		const capped = Math.min(dt, .1);
		const barsGain = s.perSec * capped;
		const energyGain = s.energyRegen * capped;
		const trauma = Math.max(0, s.trauma - capped * 3.2);
		const energyFlash = Math.max(0, s.energyFlash - capped);
		set({
			bars: s.bars + barsGain,
			totalBars: s.totalBars + barsGain,
			energy: clamp(s.energy + energyGain, 0, s.maxEnergy),
			lastTick: now,
			trauma,
			energyFlash
		});
	},
	decayCombo: (now) => {
		const s = get();
		if (s.combo > 0 && now - s.lastTapAt > 420) set({ combo: 0 });
	},
	tap: () => {
		const s = get();
		if (!s.hydrated || !s.seenIntro) return null;
		if (s.energy < 1) {
			set({
				energyFlash: .35,
				trauma: Math.min(1, s.trauma + .25)
			});
			return {
				gained: 0,
				crit: false,
				empty: true
			};
		}
		const now = Date.now();
		const combo = now - s.lastTapAt < 380 ? s.combo + 1 : 1;
		const critChance = .04 + s.luckLevel * .04;
		const crit = Math.random() < critChance;
		const comboBonus = 1 + Math.floor(combo / 12) * .15;
		const gained = s.perTap * s.multiplier * comboBonus * (crit ? 10 : 1);
		let next = {
			...s,
			bars: s.bars + gained,
			totalBars: s.totalBars + gained,
			taps: s.taps + 1,
			energy: s.energy - 1,
			lastTick: now
		};
		next.achievements = unlockAchievements(next);
		const pending = s.pendingReward ?? nextReward(next);
		set({
			...next,
			combo,
			lastTapAt: now,
			awakeUntil: now + 320,
			trauma: Math.min(1, s.trauma + (crit ? .55 : .28)),
			pendingReward: pending
		});
		scheduleSave(next);
		return {
			gained,
			crit,
			empty: false
		};
	},
	buy: (id) => {
		const s = get();
		const item = SHOP.find((x) => x.id === id);
		if (!item) return false;
		const cost = item.cost(s);
		if (s.bars < cost) return false;
		const patch = item.buy(s);
		let next = {
			...s,
			...patch,
			bars: s.bars - cost,
			lastTick: Date.now()
		};
		next.achievements = unlockAchievements(next);
		set({
			...next,
			pendingReward: s.pendingReward ?? nextReward(next)
		});
		saveRaw(next);
		return true;
	},
	claimReward: () => {
		const s = get();
		if (!s.pendingReward) return;
		const def = REWARDS.find((r) => r.id === s.pendingReward.id);
		if (!def) {
			set({ pendingReward: null });
			return;
		}
		const patch = def.apply(s);
		let next = {
			...s,
			...patch,
			claimedRewards: [...s.claimedRewards, def.id]
		};
		next.achievements = unlockAchievements(next);
		set({
			...next,
			pendingReward: nextReward(next)
		});
		saveRaw(next);
	},
	setTab: (tab) => set({ tab }),
	setName: (name) => {
		const n = name.slice(0, 18);
		set({ name: n });
		scheduleSave({
			...get(),
			name: n
		});
	},
	setMuted: (muted) => {
		set({ muted });
		scheduleSave({
			...get(),
			muted
		});
	},
	dismissIntro: () => {
		const now = Date.now();
		const s = get();
		const next = {
			...s,
			seenIntro: true,
			startedAt: s.startedAt || now,
			lastTick: now
		};
		set(next);
		saveRaw(next);
	},
	reset: () => {
		const next = {
			...DEFAULT_STATE,
			startedAt: Date.now(),
			lastTick: Date.now(),
			seenIntro: true
		};
		set({
			...next,
			hydrated: true,
			tab: null,
			pendingReward: null,
			combo: 0,
			lastTapAt: 0,
			awakeUntil: 0,
			trauma: 0,
			energyFlash: 0,
			offlineGain: 0
		});
		saveRaw(next);
	}
}));
var nf = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 0 });
function fmt(n) {
	if (!Number.isFinite(n)) return "0";
	const abs = Math.abs(n);
	if (abs >= 0xe8d4a51000) return (n / 0xe8d4a51000).toFixed(2).replace(".", ",") + " трлн";
	if (abs >= 1e9) return (n / 1e9).toFixed(2).replace(".", ",") + " млрд";
	if (abs >= 1e6) return (n / 1e6).toFixed(2).replace(".", ",") + " млн";
	if (abs >= 1e4) return (n / 1e3).toFixed(1).replace(".", ",") + " тыс";
	return nf.format(Math.floor(n));
}
function fmtExact(n) {
	return nf.format(Math.floor(n));
}
function playTime(startedAt, now = Date.now()) {
	const sec = Math.max(0, Math.floor((now - startedAt) / 1e3));
	const h = Math.floor(sec / 3600);
	const m = Math.floor(sec % 3600 / 60);
	if (h > 0) return `${h} ч ${m} мин`;
	if (m > 0) return `${m} мин`;
	return `${sec} сек`;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var NAV = [
	{
		id: "shop",
		label: "Магазин",
		icon: Store
	},
	{
		id: "ach",
		label: "Награды",
		icon: Trophy
	},
	{
		id: "top",
		label: "Рекорды",
		icon: ChartNoAxesColumn
	},
	{
		id: "me",
		label: "Профиль",
		icon: User
	}
];
var SHOP_ICONS = {
	pointer: Pointer,
	bot: Bot,
	zap: Zap,
	battery: Battery,
	heart: HeartPulse,
	clover: Star
};
var ACH_ICONS = {
	pointer: Pointer,
	flame: Flame,
	zap: Zap,
	gem: Gem,
	trophy: Trophy,
	store: Store,
	bot: Bot,
	crown: Crown
};
var REWARD_ICONS = {
	medal: Medal,
	trophy: Trophy,
	crown: Crown,
	spark: Zap,
	gem: Gem,
	rocket: Rocket
};
function BottomNav() {
	const tab = useGame((s) => s.tab);
	const setTab = useGame((s) => s.setTab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "relative z-20 shrink-0 border-t border-border bg-surface px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto grid max-w-md grid-cols-4 gap-1",
			children: NAV.map(({ id, label, icon: Icon }) => {
				const on = tab === id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setTab(on ? null : id),
					className: cn("flex min-h-12 flex-col items-center justify-center gap-0.5 rounded-lg px-1 text-xs font-medium transition-[color,background-color,transform] duration-150 ease-out active:scale-[0.96]", on ? "bg-elevated text-gold" : "text-muted"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-5",
						strokeWidth: 1.8
					}), label]
				}, id);
			})
		})
	});
}
function Sheets() {
	const tab = useGame((s) => s.tab);
	const setTab = useGame((s) => s.setTab);
	const open = tab !== null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("fixed inset-0 z-40", open ? "pointer-events-auto" : "pointer-events-none"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Закрыть",
			className: cn("absolute inset-0 bg-bg/70 transition-opacity duration-200 ease-out", open ? "opacity-100" : "opacity-0"),
			onClick: () => setTab(null)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("absolute inset-x-0 bottom-0 mx-auto max-h-[78dvh] w-full max-w-lg overflow-hidden rounded-t-2xl border border-border bg-surface shadow-[0_-12px_40px_rgba(0,0,0,0.45)] transition-transform duration-300 ease-out", open ? "translate-y-0" : "translate-y-full"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center justify-between px-5 pb-2 pt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto h-1 w-10 rounded-full bg-border-strong" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-5 pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-lg font-semibold tracking-[-0.02em] text-fg",
						children: [
							tab === "shop" ? "Магазин" : null,
							tab === "ach" ? "Награды" : null,
							tab === "top" ? "Рекорды склада" : null,
							tab === "me" ? "Профиль" : null
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTab(null),
						className: "flex size-9 items-center justify-center rounded-lg text-muted transition-colors duration-150 hover:bg-elevated hover:text-fg",
						"aria-label": "Закрыть",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[calc(78dvh-5rem)] overflow-y-auto px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))]",
					children: [
						tab === "shop" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopList, {}) : null,
						tab === "ach" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AchList, {}) : null,
						tab === "top" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopList, {}) : null,
						tab === "me" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Profile, {}) : null
					]
				})
			]
		})]
	});
}
function ShopList() {
	const bars = useGame((s) => s.bars);
	const buy = useGame((s) => s.buy);
	const levels = {
		clickLevel: useGame((s) => s.clickLevel),
		autoLevel: useGame((s) => s.autoLevel),
		energyLevel: useGame((s) => s.energyLevel),
		regenLevel: useGame((s) => s.regenLevel),
		luckLevel: useGame((s) => s.luckLevel),
		multiplier: useGame((s) => s.multiplier)
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2",
		children: SHOP.map((item) => {
			const Icon = SHOP_ICONS[item.icon];
			const cost = item.cost({
				...DEFAULT_STATE,
				...levels
			});
			const owned = item.owned({
				...DEFAULT_STATE,
				...levels
			});
			const can = bars >= cost;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-3 rounded-xl bg-elevated p-3 ring-1 ring-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-11 shrink-0 items-center justify-center rounded-lg bg-surface text-gold",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-5",
							strokeWidth: 1.8
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-semibold text-fg",
								children: item.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: item.desc
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-0.5 text-xs text-subtle",
								children: ["ур. ", owned]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: !can,
						onClick: () => {
							if (buy(item.id)) playBuy();
						},
						className: cn("min-h-10 shrink-0 rounded-lg px-3 font-display text-xs font-semibold tabular-nums transition-[transform,opacity] duration-150 active:scale-[0.96] disabled:cursor-not-allowed disabled:opacity-40", can ? "bg-gold text-gold-fg" : "bg-surface text-muted ring-1 ring-border"),
						children: fmt(cost)
					})
				]
			}, item.id);
		})
	});
}
function AchList() {
	const unlocked = useGame((s) => s.achievements);
	const have = new Set(unlocked);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2",
		children: ACHIEVEMENTS.map((a) => {
			const Icon = ACH_ICONS[a.icon];
			const done = have.has(a.id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: cn("flex items-center gap-3 rounded-xl p-3 ring-1", done ? "bg-elevated ring-gold/35" : "bg-elevated/50 ring-border opacity-55"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("flex size-11 shrink-0 items-center justify-center rounded-lg", done ? "bg-gold/15 text-gold" : "bg-surface text-muted"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-5",
						strokeWidth: 1.8
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-fg",
					children: a.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: a.desc
				})] })]
			}, a.id);
		})
	});
}
function TopList() {
	const total = useGame((s) => s.totalBars);
	const rows = buildBoard(useGame((s) => s.name), total);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-1.5",
		children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: cn("flex items-center gap-3 rounded-xl px-3 py-2.5 ring-1", row.me ? "bg-gold/10 ring-gold/40" : "bg-elevated ring-border"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-6 font-display text-sm font-semibold tabular-nums text-muted",
					children: row.rank
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("flex-1 truncate text-sm font-medium", row.me ? "text-gold" : "text-fg"),
					children: row.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-sm tabular-nums text-muted",
					children: fmt(row.score)
				})
			]
		}, row.rank + row.name))
	});
}
function hash(s) {
	let h = 2166136261;
	for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
	return h >>> 0;
}
function buildBoard(name, score) {
	return [...BOT_NAMES.map((n, i) => {
		const factor = .35 + hash(n + String(i)) % 1800 / 1800 * 3.4;
		return {
			name: n,
			score: Math.max(12, Math.floor((score + 400) * factor * (.4 + i % 7 * .18))),
			me: false
		};
	}), {
		name: name || "Сашка",
		score: Math.floor(score),
		me: true
	}].sort((a, b) => b.score - a.score).slice(0, 10).map((r, i) => ({
		...r,
		rank: i + 1
	}));
}
function Profile() {
	const name = useGame((s) => s.name);
	const setName = useGame((s) => s.setName);
	const muted = useGame((s) => s.muted);
	const setMuted$1 = useGame((s) => s.setMuted);
	const reset = useGame((s) => s.reset);
	const totalBars = useGame((s) => s.totalBars);
	const taps = useGame((s) => s.taps);
	const startedAt = useGame((s) => s.startedAt);
	const achievements = useGame((s) => s.achievements);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-1.5 block text-xs font-medium text-muted",
					children: "Имя на складе"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: name,
					maxLength: 18,
					onChange: (e) => setName(e.target.value),
					className: "h-11 w-full rounded-xl bg-elevated px-3 text-sm text-fg outline-none ring-1 ring-border focus:ring-gold/50"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Всего сникерсов",
						value: fmtExact(totalBars)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Тапов",
						value: fmtExact(taps)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "В игре",
						value: playTime(startedAt)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Наград",
						value: `${achievements.length} / ${ACHIEVEMENTS.length}`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					const next = !muted;
					setMuted$1(next);
					setMuted(next);
				},
				className: "flex min-h-11 items-center justify-center gap-2 rounded-xl bg-elevated text-sm font-medium text-fg ring-1 ring-border transition-transform duration-150 active:scale-[0.96]",
				children: [muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }), muted ? "Звук выключен" : "Звук включён"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					if (window.confirm("Сбросить весь прогресс?")) reset();
				},
				className: "flex min-h-11 items-center justify-center gap-2 rounded-xl bg-danger/15 text-sm font-medium text-danger ring-1 ring-danger/25 transition-transform duration-150 active:scale-[0.96]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Сбросить прогресс"]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-elevated p-3 ring-1 ring-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-0.5 font-display text-sm font-semibold tabular-nums text-fg",
			children: value
		})]
	});
}
function RewardModal() {
	const pending = useGame((s) => s.pendingReward);
	const claim = useGame((s) => s.claimReward);
	if (!pending) return null;
	const Icon = REWARD_ICONS[pending.icon];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-bg/80 px-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "reward-pop w-full max-w-sm rounded-2xl border border-gold/40 bg-surface p-6 text-center shadow-[0_24px_60px_rgba(0,0,0,0.5)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto flex size-16 items-center justify-center rounded-2xl bg-gold/15 text-gold",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-8",
						strokeWidth: 1.6
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-4 font-display text-xl font-semibold tracking-[-0.02em] text-gold",
					children: pending.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted text-pretty",
					children: pending.text
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: claim,
					className: "mt-5 inline-flex min-h-12 w-full items-center justify-center rounded-xl bg-gold font-display text-base font-semibold text-gold-fg transition-transform duration-150 active:scale-[0.96]",
					children: "Забрать"
				})
			]
		})
	});
}
function OfflineBanner() {
	const gain = useGame((s) => s.offlineGain);
	const [show, setShow] = (0, import_react.useState)(gain >= 1);
	if (!show || gain < 1) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => setShow(false),
		className: "absolute left-1/2 top-[max(4.5rem,calc(env(safe-area-inset-top)+3.5rem))] z-30 w-[min(92%,24rem)] -translate-x-1/2 rounded-xl bg-surface/95 px-4 py-3 text-center text-sm text-fg shadow-lg ring-1 ring-gold/30",
		children: [
			"Пока тебя не было, склад принёс",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display font-semibold text-gold",
				children: fmt(gain)
			})
		]
	});
}
function Hud() {
	const bars = useGame((s) => s.bars);
	const perTap = useGame((s) => s.perTap * s.multiplier);
	const perSec = useGame((s) => s.perSec);
	const combo = useGame((s) => s.combo);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "relative z-20 shrink-0 px-4 pb-2 pt-[max(0.75rem,env(safe-area-inset-top))]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-md flex-col items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/game/bar-icon.webp",
					alt: "",
					className: "h-8 w-auto drop-shadow-[0_2px_8px_rgba(0,0,0,0.45)]"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-[clamp(1.85rem,7vw,2.35rem)] font-semibold leading-none tracking-[-0.03em] text-gold tabular-nums",
					children: fmt(bars)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1.5 flex items-center gap-3 text-xs font-medium text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"+",
						fmt(perTap),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: "за тап"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1 w-1 rounded-full bg-border-strong" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [fmt(perSec), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-subtle",
						children: "/сек"
					})] }),
					combo >= 5 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1 w-1 rounded-full bg-border-strong" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-gold",
						children: ["комбо ×", combo]
					})] }) : null
				]
			})]
		})
	});
}
function StartScreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-dvh flex-col overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/game/warehouse.jpg",
				alt: "",
				className: "absolute inset-0 size-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-bg/55 via-bg/25 to-bg/85" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 flex min-h-0 flex-1 flex-col items-center justify-end px-6 pb-10 pt-[max(2.5rem,env(safe-area-inset-top))]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/game/sasha-sleep.webp",
						alt: "Сашка спит",
						className: "pointer-events-none mb-2 h-[min(52dvh,420px)] w-auto object-contain drop-shadow-[0_18px_40px_rgba(0,0,0,0.55)]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-[0.7rem] font-semibold uppercase tracking-[0.28em] text-gold/80",
						children: "Склад · Сникерс"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-2 text-center font-display text-[clamp(2.1rem,8vw,3.4rem)] font-semibold leading-[1.05] tracking-[-0.03em] text-gold text-balance",
						children: ["Сашка", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-[0.62em] font-medium tracking-[-0.02em] text-fg",
							children: "за работой"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-[22rem] text-center text-sm leading-snug text-muted text-pretty",
						children: "Он спит на золотом складе. Буди его тапами — батончики полетят."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							unlockAudio();
							const g = useGame.getState();
							if (!g.hydrated) g.hydrate();
							g.dismissIntro();
						},
						className: "mt-6 inline-flex min-h-12 w-full max-w-sm items-center justify-center gap-2 rounded-xl bg-gold px-6 font-display text-base font-semibold text-gold-fg transition-[transform,opacity] duration-150 ease-out active:scale-[0.96]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pointer, {
							className: "size-5",
							strokeWidth: 2.2
						}), "Разбудить Сашку"]
					})
				]
			})
		]
	});
}
var pid = 1;
function prefersReduced() {
	return typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
function TapStage() {
	const tap = useGame((s) => s.tap);
	const energy = useGame((s) => s.energy);
	const maxEnergy = useGame((s) => s.maxEnergy);
	const pendingReward = useGame((s) => s.pendingReward);
	const [awake, setAwake] = (0, import_react.useState)(false);
	const [emptyPulse, setEmptyPulse] = (0, import_react.useState)(false);
	const [particles, setParticles] = (0, import_react.useState)([]);
	const [floaters, setFloaters] = (0, import_react.useState)([]);
	const stageRef = (0, import_react.useRef)(null);
	const trauma = (0, import_react.useRef)(0);
	const awakeTimer = (0, import_react.useRef)(0);
	const lastReward = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (pendingReward && pendingReward.id !== lastReward.current) {
			lastReward.current = pendingReward.id;
			playReward();
		}
	}, [pendingReward]);
	(0, import_react.useEffect)(() => {
		const reduced = prefersReduced();
		let raf = 0;
		let last = performance.now();
		const loop = (t) => {
			const dt = Math.min(.05, (t - last) / 1e3);
			last = t;
			trauma.current = Math.max(0, trauma.current - dt * 3.4);
			const el = stageRef.current;
			if (el) {
				const shake = trauma.current * trauma.current;
				if (reduced || shake < .002) el.style.transform = "";
				else {
					const ox = (Math.random() * 2 - 1) * 10 * shake;
					const oy = (Math.random() * 2 - 1) * 8 * shake;
					el.style.transform = `translate(${ox.toFixed(2)}px, ${oy.toFixed(2)}px)`;
				}
			}
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, []);
	const spawn = (0, import_react.useCallback)((clientX, clientY, gained, crit) => {
		const root = stageRef.current;
		if (!root) return;
		const rect = root.getBoundingClientRect();
		const x = clientX - rect.left;
		const y = clientY - rect.top;
		const count = prefersReduced() ? 2 : crit ? 10 : 6;
		const born = performance.now();
		const next = [];
		for (let i = 0; i < count; i++) {
			const ang = Math.random() * Math.PI * 2;
			const dist = 70 + Math.random() * (crit ? 160 : 110);
			next.push({
				id: pid++,
				x,
				y,
				dx: Math.cos(ang) * dist,
				dy: Math.sin(ang) * dist - 30,
				rot: Math.random() * 720 - 360,
				spin: 0,
				scale: .7 + Math.random() * .5,
				born,
				life: .85
			});
		}
		setParticles((p) => [...p.slice(-28), ...next]);
		setFloaters((f) => [...f.slice(-10), {
			id: pid++,
			x,
			y,
			text: `+${fmt(gained)}`,
			born,
			crit
		}]);
		window.setTimeout(() => {
			setParticles((p) => p.filter((q) => q.born !== born));
			setFloaters((f) => f.filter((q) => q.born !== born));
		}, 900);
	}, []);
	const onPointerDown = (e) => {
		if (e.pointerType === "mouse" && e.button !== 0) return;
		e.preventDefault();
		unlockAudio();
		const res = tap();
		if (!res) return;
		if (res.empty) {
			playEmpty();
			setEmptyPulse(true);
			window.setTimeout(() => setEmptyPulse(false), 280);
			trauma.current = Math.min(1, trauma.current + .22);
			return;
		}
		playTap(res.crit);
		trauma.current = Math.min(1, trauma.current + (res.crit ? .62 : .3));
		setAwake(true);
		window.clearTimeout(awakeTimer.current);
		awakeTimer.current = window.setTimeout(() => setAwake(false), 340);
		spawn(e.clientX, e.clientY, res.gained, res.crit);
	};
	const ratio = maxEnergy > 0 ? energy / maxEnergy : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: stageRef,
		className: "relative min-h-0 flex-1 touch-none select-none",
		onPointerDown,
		role: "button",
		tabIndex: 0,
		"aria-label": "Тапнуть Сашку",
		onKeyDown: (e) => {
			if (e.key === " " || e.key === "Enter") {
				e.preventDefault();
				const r = stageRef.current?.getBoundingClientRect();
				if (!r) return;
				onPointerDown({
					pointerType: "mouse",
					button: 0,
					preventDefault: () => {},
					clientX: r.left + r.width / 2,
					clientY: r.top + r.height / 2
				});
			}
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/game/warehouse.jpg",
					alt: "",
					className: "size-full object-cover object-center"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-bg/50 via-transparent to-bg/80" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 flex items-center justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("relative h-[78%] max-h-[520px] w-[min(86%,420px)]", awake && "sasha-press"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/game/sasha-sleep.webp",
							alt: "",
							draggable: false,
							className: cn("absolute inset-0 m-auto h-full w-full object-contain drop-shadow-[0_16px_40px_rgba(0,0,0,0.5)] transition-[opacity,filter] duration-200", awake ? "opacity-0" : "opacity-100")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/game/sasha-awake.webp",
							alt: "",
							draggable: false,
							className: cn("absolute inset-0 m-auto h-full w-full object-contain drop-shadow-[0_0_28px_rgba(232,185,35,0.28)] transition-[opacity,filter] duration-200", awake ? "opacity-100 brightness-110" : "opacity-0")
						}),
						!awake ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pointer-events-none absolute right-[18%] top-[8%] font-display text-lg font-semibold text-gold/70",
							"aria-hidden": true,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "zzz zzz-1",
									children: "z"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "zzz zzz-2",
									children: "z"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "zzz zzz-3",
									children: "z"
								})
							]
						}) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-0 overflow-hidden",
				children: [particles.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/game/bar.webp",
					alt: "",
					className: "particle-bar absolute left-0 top-0 h-10 w-auto",
					style: {
						left: p.x,
						top: p.y,
						["--dx"]: `${p.dx}px`,
						["--dy"]: `${p.dy}px`,
						["--rot"]: `${p.rot}deg`,
						["--sc"]: String(p.scale)
					}
				}, p.id)), floaters.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("float-text absolute font-display text-xl font-semibold tabular-nums", f.crit ? "text-gold text-[1.45rem]" : "text-fg"),
					style: {
						left: f.x,
						top: f.y
					},
					children: [f.crit ? "крит " : "", f.text]
				}, f.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-x-0 bottom-3 px-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("mx-auto max-w-sm", emptyPulse && "energy-shake"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-center justify-between text-xs font-medium text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Энергия" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums text-fg",
							children: [
								Math.floor(energy),
								" / ",
								maxEnergy
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-2 overflow-hidden rounded-full bg-elevated ring-1 ring-border",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-gold transition-[width] duration-150 ease-out",
							style: { width: `${Math.max(0, Math.min(100, ratio * 100))}%` }
						})
					})]
				})
			})
		]
	});
}
function GameApp() {
	const seenIntro = useGame((s) => s.seenIntro);
	const muted = useGame((s) => s.muted);
	(0, import_react.useEffect)(() => {
		useGame.getState().hydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		setMuted(muted);
	}, [muted]);
	(0, import_react.useEffect)(() => {
		let raf = 0;
		let last = performance.now();
		let acc = 0;
		const loop = (t) => {
			const dt = Math.min(.1, (t - last) / 1e3);
			last = t;
			acc += dt;
			if (acc >= .1) {
				const g = useGame.getState();
				g.tick(acc, Date.now());
				g.decayCombo(Date.now());
				acc = 0;
			}
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, []);
	(0, import_react.useEffect)(() => {
		const flush = () => useGame.getState().persist();
		const onVis = () => {
			if (document.visibilityState === "hidden") flush();
			else unlockAudio();
		};
		window.addEventListener("pagehide", flush);
		document.addEventListener("visibilitychange", onVis);
		return () => {
			window.removeEventListener("pagehide", flush);
			document.removeEventListener("visibilitychange", onVis);
		};
	}, []);
	if (!seenIntro) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StartScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-dvh flex-col overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hud, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TapStage, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheets, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RewardModal, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OfflineBanner, {})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { Home as component };
