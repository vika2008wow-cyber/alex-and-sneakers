//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CaDXd0Vo.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-zAIu0gnj.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-zAIu0gnj.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Hx3pixu3.js"]
	}
} });
//#endregion
export { tsrStartManifest };
