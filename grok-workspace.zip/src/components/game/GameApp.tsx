import { useEffect } from "react";
import { setMuted, unlockAudio } from "@/game/audio";
import { useGame } from "@/game/store";
import { BottomNav, OfflineBanner, RewardModal, Sheets } from "./NavSheets";
import { Hud } from "./Hud";
import { StartScreen } from "./StartScreen";
import { TapStage } from "./TapStage";

export function GameApp() {
  const seenIntro = useGame((s) => s.seenIntro);
  const muted = useGame((s) => s.muted);

  useEffect(() => {
    useGame.getState().hydrate();
  }, []);

  useEffect(() => {
    setMuted(muted);
  }, [muted]);

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    let acc = 0;
    const loop = (t: number) => {
      const dt = Math.min(0.1, (t - last) / 1000);
      last = t;
      acc += dt;
      if (acc >= 0.1) {
        const g = useGame.getState();
        g.tick(acc, Date.now());
        g.decayCombo(Date.now());
        acc = 0;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  useEffect(() => {
    const flush = () => useGame.getState().persist();
    const onVis = () => {
      if (document.visibilityState === "hidden") flush();
      else unlockAudio();
    };
    window.addEventListener("pagehide", flush);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.removeEventListener("pagehide", flush);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, []);

  if (!seenIntro) return <StartScreen />;

  return (
    <div className="relative flex h-dvh flex-col overflow-hidden bg-bg text-fg">
      <Hud />
      <TapStage />
      <BottomNav />
      <Sheets />
      <RewardModal />
      <OfflineBanner />
    </div>
  );
}
