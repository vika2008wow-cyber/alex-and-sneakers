import { fmt } from "@/game/format";
import { useGame } from "@/game/store";

export function Hud() {
  const bars = useGame((s) => s.bars);
  const perTap = useGame((s) => s.perTap * s.multiplier);
  const perSec = useGame((s) => s.perSec);
  const combo = useGame((s) => s.combo);

  return (
    <header className="relative z-20 shrink-0 px-4 pb-2 pt-[max(0.75rem,env(safe-area-inset-top))]">
      <div className="mx-auto flex max-w-md flex-col items-center">
        <div className="flex items-center gap-2.5">
          <img src="/game/bar-icon.webp" alt="" className="h-8 w-auto drop-shadow-[0_2px_8px_rgba(0,0,0,0.45)]" />
          <p className="font-display text-[clamp(1.85rem,7vw,2.35rem)] font-semibold leading-none tracking-[-0.03em] text-gold tabular-nums">
            {fmt(bars)}
          </p>
        </div>
        <div className="mt-1.5 flex items-center gap-3 text-xs font-medium text-muted">
          <span>
            +{fmt(perTap)} <span className="text-subtle">за тап</span>
          </span>
          <span className="h-1 w-1 rounded-full bg-border-strong" />
          <span>
            {fmt(perSec)}
            <span className="text-subtle">/сек</span>
          </span>
          {combo >= 5 ? (
            <>
              <span className="h-1 w-1 rounded-full bg-border-strong" />
              <span className="text-gold">комбо ×{combo}</span>
            </>
          ) : null}
        </div>
      </div>
    </header>
  );
}
