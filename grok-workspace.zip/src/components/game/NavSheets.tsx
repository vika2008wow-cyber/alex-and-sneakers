import { useState } from "react";
import {
  Battery,
  Bot,
  ChartNoAxesColumn,
  Crown,
  Flame,
  Gem,
  HeartPulse,
  Medal,
  Pointer,
  Rocket,
  RotateCcw,
  Star,
  Store,
  Trophy,
  User,
  Volume2,
  VolumeX,
  X,
  Zap,
} from "lucide-react";
import { playBuy, setMuted as setAudioMuted } from "@/game/audio";
import { ACHIEVEMENTS, BOT_NAMES, DEFAULT_STATE, SHOP } from "@/game/constants";
import { fmt, fmtExact, playTime } from "@/game/format";
import { useGame } from "@/game/store";
import type { TabId } from "@/game/types";
import { cn } from "@/lib/utils";

const NAV: { id: Exclude<TabId, null>; label: string; icon: typeof Store }[] = [
  { id: "shop", label: "Магазин", icon: Store },
  { id: "ach", label: "Награды", icon: Trophy },
  { id: "top", label: "Рекорды", icon: ChartNoAxesColumn },
  { id: "me", label: "Профиль", icon: User },
];

const SHOP_ICONS = {
  pointer: Pointer,
  bot: Bot,
  zap: Zap,
  battery: Battery,
  heart: HeartPulse,
  clover: Star,
};

const ACH_ICONS = {
  pointer: Pointer,
  flame: Flame,
  zap: Zap,
  gem: Gem,
  trophy: Trophy,
  store: Store,
  bot: Bot,
  crown: Crown,
};

const REWARD_ICONS = {
  medal: Medal,
  trophy: Trophy,
  crown: Crown,
  spark: Zap,
  gem: Gem,
  rocket: Rocket,
};

export function BottomNav() {
  const tab = useGame((s) => s.tab);
  const setTab = useGame((s) => s.setTab);

  return (
    <nav className="relative z-20 shrink-0 border-t border-border bg-surface px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-2">
      <div className="mx-auto grid max-w-md grid-cols-4 gap-1">
        {NAV.map(({ id, label, icon: Icon }) => {
          const on = tab === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => setTab(on ? null : id)}
              className={cn(
                "flex min-h-12 flex-col items-center justify-center gap-0.5 rounded-lg px-1 text-xs font-medium transition-[color,background-color,transform] duration-150 ease-out active:scale-[0.96]",
                on ? "bg-elevated text-gold" : "text-muted",
              )}
            >
              <Icon className="size-5" strokeWidth={1.8} />
              {label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}

export function Sheets() {
  const tab = useGame((s) => s.tab);
  const setTab = useGame((s) => s.setTab);
  const open = tab !== null;

  return (
    <div
      className={cn("fixed inset-0 z-40", open ? "pointer-events-auto" : "pointer-events-none")}
      aria-hidden={!open}
    >
      <button
        type="button"
        aria-label="Закрыть"
        className={cn(
          "absolute inset-0 bg-bg/70 transition-opacity duration-200 ease-out",
          open ? "opacity-100" : "opacity-0",
        )}
        onClick={() => setTab(null)}
      />
      <div
        className={cn(
          "absolute inset-x-0 bottom-0 mx-auto max-h-[78dvh] w-full max-w-lg overflow-hidden rounded-t-2xl border border-border bg-surface shadow-[0_-12px_40px_rgba(0,0,0,0.45)] transition-transform duration-300 ease-out",
          open ? "translate-y-0" : "translate-y-full",
        )}
      >
        <div className="flex items-center justify-between px-5 pb-2 pt-3">
          <div className="mx-auto h-1 w-10 rounded-full bg-border-strong" />
        </div>
        <div className="flex items-center justify-between px-5 pb-3">
          <h2 className="font-display text-lg font-semibold tracking-[-0.02em] text-fg">
            {tab === "shop" ? "Магазин" : null}
            {tab === "ach" ? "Награды" : null}
            {tab === "top" ? "Рекорды склада" : null}
            {tab === "me" ? "Профиль" : null}
          </h2>
          <button
            type="button"
            onClick={() => setTab(null)}
            className="flex size-9 items-center justify-center rounded-lg text-muted transition-colors duration-150 hover:bg-elevated hover:text-fg"
            aria-label="Закрыть"
          >
            <X className="size-4" />
          </button>
        </div>
        <div className="max-h-[calc(78dvh-5rem)] overflow-y-auto px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))]">
          {tab === "shop" ? <ShopList /> : null}
          {tab === "ach" ? <AchList /> : null}
          {tab === "top" ? <TopList /> : null}
          {tab === "me" ? <Profile /> : null}
        </div>
      </div>
    </div>
  );
}

function ShopList() {
  const bars = useGame((s) => s.bars);
  const buy = useGame((s) => s.buy);
  const clickLevel = useGame((s) => s.clickLevel);
  const autoLevel = useGame((s) => s.autoLevel);
  const energyLevel = useGame((s) => s.energyLevel);
  const regenLevel = useGame((s) => s.regenLevel);
  const luckLevel = useGame((s) => s.luckLevel);
  const multiplier = useGame((s) => s.multiplier);
  const levels = { clickLevel, autoLevel, energyLevel, regenLevel, luckLevel, multiplier };

  return (
    <ul className="flex flex-col gap-2">
      {SHOP.map((item) => {
        const Icon = SHOP_ICONS[item.icon];
        const cost = item.cost({ ...DEFAULT_STATE, ...levels });
        const owned = item.owned({ ...DEFAULT_STATE, ...levels });
        const can = bars >= cost;

        return (
          <li
            key={item.id}
            className="flex items-center gap-3 rounded-xl bg-elevated p-3 ring-1 ring-border"
          >
            <div className="flex size-11 shrink-0 items-center justify-center rounded-lg bg-surface text-gold">
              <Icon className="size-5" strokeWidth={1.8} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-fg">{item.name}</p>
              <p className="text-xs text-muted">{item.desc}</p>
              <p className="mt-0.5 text-xs text-subtle">ур. {owned}</p>
            </div>
            <button
              type="button"
              disabled={!can}
              onClick={() => {
                if (buy(item.id)) playBuy();
              }}
              className={cn(
                "min-h-10 shrink-0 rounded-lg px-3 font-display text-xs font-semibold tabular-nums transition-[transform,opacity] duration-150 active:scale-[0.96] disabled:cursor-not-allowed disabled:opacity-40",
                can ? "bg-gold text-gold-fg" : "bg-surface text-muted ring-1 ring-border",
              )}
            >
              {fmt(cost)}
            </button>
          </li>
        );
      })}
    </ul>
  );
}

function AchList() {
  const unlocked = useGame((s) => s.achievements);
  const have = new Set(unlocked);
  return (
    <ul className="flex flex-col gap-2">
      {ACHIEVEMENTS.map((a) => {
        const Icon = ACH_ICONS[a.icon];
        const done = have.has(a.id);
        return (
          <li
            key={a.id}
            className={cn(
              "flex items-center gap-3 rounded-xl p-3 ring-1",
              done ? "bg-elevated ring-gold/35" : "bg-elevated/50 ring-border opacity-55",
            )}
          >
            <div
              className={cn(
                "flex size-11 shrink-0 items-center justify-center rounded-lg",
                done ? "bg-gold/15 text-gold" : "bg-surface text-muted",
              )}
            >
              <Icon className="size-5" strokeWidth={1.8} />
            </div>
            <div>
              <p className="text-sm font-semibold text-fg">{a.title}</p>
              <p className="text-xs text-muted">{a.desc}</p>
            </div>
          </li>
        );
      })}
    </ul>
  );
}

function TopList() {
  const total = useGame((s) => s.totalBars);
  const name = useGame((s) => s.name);
  const rows = buildBoard(name, total);

  return (
    <ul className="flex flex-col gap-1.5">
      {rows.map((row) => (
        <li
          key={row.rank + row.name}
          className={cn(
            "flex items-center gap-3 rounded-xl px-3 py-2.5 ring-1",
            row.me ? "bg-gold/10 ring-gold/40" : "bg-elevated ring-border",
          )}
        >
          <span className="w-6 font-display text-sm font-semibold tabular-nums text-muted">{row.rank}</span>
          <span className={cn("flex-1 truncate text-sm font-medium", row.me ? "text-gold" : "text-fg")}>
            {row.name}
          </span>
          <span className="font-display text-sm tabular-nums text-muted">{fmt(row.score)}</span>
        </li>
      ))}
    </ul>
  );
}

function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h >>> 0;
}

function buildBoard(name: string, score: number) {
  const bots = BOT_NAMES.map((n, i) => {
    const h = hash(n + String(i));
    const factor = 0.35 + ((h % 1800) / 1800) * 3.4;
    return {
      name: n,
      score: Math.max(12, Math.floor((score + 400) * factor * (0.4 + (i % 7) * 0.18))),
      me: false,
    };
  });
  const all = [...bots, { name: name || "Сашка", score: Math.floor(score), me: true }].sort(
    (a, b) => b.score - a.score,
  );
  return all.slice(0, 10).map((r, i) => ({ ...r, rank: i + 1 }));
}

function Profile() {
  const name = useGame((s) => s.name);
  const setName = useGame((s) => s.setName);
  const muted = useGame((s) => s.muted);
  const setMuted = useGame((s) => s.setMuted);
  const reset = useGame((s) => s.reset);
  const totalBars = useGame((s) => s.totalBars);
  const taps = useGame((s) => s.taps);
  const startedAt = useGame((s) => s.startedAt);
  const achievements = useGame((s) => s.achievements);

  return (
    <div className="flex flex-col gap-4">
      <label className="block">
        <span className="mb-1.5 block text-xs font-medium text-muted">Имя на складе</span>
        <input
          value={name}
          maxLength={18}
          onChange={(e) => setName(e.target.value)}
          className="h-11 w-full rounded-xl bg-elevated px-3 text-sm text-fg outline-none ring-1 ring-border focus:ring-gold/50"
        />
      </label>
      <dl className="grid grid-cols-2 gap-2">
        <Stat label="Всего сникерсов" value={fmtExact(totalBars)} />
        <Stat label="Тапов" value={fmtExact(taps)} />
        <Stat label="В игре" value={playTime(startedAt)} />
        <Stat label="Наград" value={`${achievements.length} / ${ACHIEVEMENTS.length}`} />
      </dl>
      <button
        type="button"
        onClick={() => {
          const next = !muted;
          setMuted(next);
          setAudioMuted(next);
        }}
        className="flex min-h-11 items-center justify-center gap-2 rounded-xl bg-elevated text-sm font-medium text-fg ring-1 ring-border transition-transform duration-150 active:scale-[0.96]"
      >
        {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
        {muted ? "Звук выключен" : "Звук включён"}
      </button>
      <button
        type="button"
        onClick={() => {
          if (window.confirm("Сбросить весь прогресс?")) reset();
        }}
        className="flex min-h-11 items-center justify-center gap-2 rounded-xl bg-danger/15 text-sm font-medium text-danger ring-1 ring-danger/25 transition-transform duration-150 active:scale-[0.96]"
      >
        <RotateCcw className="size-4" />
        Сбросить прогресс
      </button>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-elevated p-3 ring-1 ring-border">
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="mt-0.5 font-display text-sm font-semibold tabular-nums text-fg">{value}</dd>
    </div>
  );
}

export function RewardModal() {
  const pending = useGame((s) => s.pendingReward);
  const claim = useGame((s) => s.claimReward);
  if (!pending) return null;
  const Icon = REWARD_ICONS[pending.icon];
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-bg/80 px-5">
      <div className="reward-pop w-full max-w-sm rounded-2xl border border-gold/40 bg-surface p-6 text-center shadow-[0_24px_60px_rgba(0,0,0,0.5)]">
        <div className="mx-auto flex size-16 items-center justify-center rounded-2xl bg-gold/15 text-gold">
          <Icon className="size-8" strokeWidth={1.6} />
        </div>
        <h3 className="mt-4 font-display text-xl font-semibold tracking-[-0.02em] text-gold">{pending.title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-muted text-pretty">{pending.text}</p>
        <button
          type="button"
          onClick={claim}
          className="mt-5 inline-flex min-h-12 w-full items-center justify-center rounded-xl bg-gold font-display text-base font-semibold text-gold-fg transition-transform duration-150 active:scale-[0.96]"
        >
          Забрать
        </button>
      </div>
    </div>
  );
}

export function OfflineBanner() {
  const gain = useGame((s) => s.offlineGain);
  const [show, setShow] = useState(gain >= 1);
  if (!show || gain < 1) return null;
  return (
    <button
      type="button"
      onClick={() => setShow(false)}
      className="absolute left-1/2 top-[max(4.5rem,calc(env(safe-area-inset-top)+3.5rem))] z-30 w-[min(92%,24rem)] -translate-x-1/2 rounded-xl bg-surface/95 px-4 py-3 text-center text-sm text-fg shadow-lg ring-1 ring-gold/30"
    >
      Пока тебя не было, склад принёс{" "}
      <span className="font-display font-semibold text-gold">{fmt(gain)}</span>
    </button>
  );
}
