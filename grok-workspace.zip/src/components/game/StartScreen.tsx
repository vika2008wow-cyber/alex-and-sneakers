import { Pointer } from "lucide-react";
import { unlockAudio } from "@/game/audio";
import { useGame } from "@/game/store";

export function StartScreen() {

  return (
    <div className="relative flex h-dvh flex-col overflow-hidden bg-bg text-fg">
      <img
        src="/game/warehouse.jpg"
        alt=""
        className="absolute inset-0 size-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-bg/55 via-bg/25 to-bg/85" />
      <div className="relative z-10 flex min-h-0 flex-1 flex-col items-center justify-end px-6 pb-10 pt-[max(2.5rem,env(safe-area-inset-top))]">
        <img
          src="/game/sasha-sleep.webp"
          alt="Сашка спит"
          className="pointer-events-none mb-2 h-[min(52dvh,420px)] w-auto object-contain drop-shadow-[0_18px_40px_rgba(0,0,0,0.55)]"
        />
        <p className="font-display text-[0.7rem] font-semibold uppercase tracking-[0.28em] text-gold/80">
          Склад · Сникерс
        </p>
        <h1 className="mt-2 text-center font-display text-[clamp(2.1rem,8vw,3.4rem)] font-semibold leading-[1.05] tracking-[-0.03em] text-gold text-balance">
          Сашка
          <span className="block text-[0.62em] font-medium tracking-[-0.02em] text-fg">
            за работой
          </span>
        </h1>
        <p className="mt-3 max-w-[22rem] text-center text-sm leading-snug text-muted text-pretty">
          Он спит на золотом складе. Буди его тапами — батончики полетят.
        </p>
        <button
          type="button"
          onClick={() => {
            unlockAudio();
            const g = useGame.getState();
            if (!g.hydrated) g.hydrate();
            g.dismissIntro();
          }}
          className="mt-6 inline-flex min-h-12 w-full max-w-sm items-center justify-center gap-2 rounded-xl bg-gold px-6 font-display text-base font-semibold text-gold-fg transition-[transform,opacity] duration-150 ease-out active:scale-[0.96]"
        >
          <Pointer className="size-5" strokeWidth={2.2} />
          Разбудить Сашку
        </button>
      </div>
    </div>
  );
}
