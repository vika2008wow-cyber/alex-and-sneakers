import { useCallback, useEffect, useRef, useState } from "react";
import { playEmpty, playReward, playTap, unlockAudio } from "@/game/audio";
import { fmt } from "@/game/format";
import { useGame } from "@/game/store";
import type { Floater, Particle } from "@/game/types";
import { cn } from "@/lib/utils";

let pid = 1;

function prefersReduced() {
  return typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

export function TapStage() {
  const tap = useGame((s) => s.tap);
  const energy = useGame((s) => s.energy);
  const maxEnergy = useGame((s) => s.maxEnergy);
  const pendingReward = useGame((s) => s.pendingReward);
  const [awake, setAwake] = useState(false);
  const [emptyPulse, setEmptyPulse] = useState(false);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [floaters, setFloaters] = useState<Floater[]>([]);
  const stageRef = useRef<HTMLDivElement>(null);
  const trauma = useRef(0);
  const awakeTimer = useRef<number>(0);
  const lastReward = useRef<string | null>(null);

  useEffect(() => {
    if (pendingReward && pendingReward.id !== lastReward.current) {
      lastReward.current = pendingReward.id;
      playReward();
    }
  }, [pendingReward]);

  useEffect(() => {
    const reduced = prefersReduced();
    let raf = 0;
    let last = performance.now();
    const loop = (t: number) => {
      const dt = Math.min(0.05, (t - last) / 1000);
      last = t;
      trauma.current = Math.max(0, trauma.current - dt * 3.4);
      const el = stageRef.current;
      if (el) {
        const shake = trauma.current * trauma.current;
        if (reduced || shake < 0.002) {
          el.style.transform = "";
        } else {
          const ox = (Math.random() * 2 - 1) * 10 * shake;
          const oy = (Math.random() * 2 - 1) * 8 * shake;
          el.style.transform = `translate(${ox.toFixed(2)}px, ${oy.toFixed(2)}px)`;
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  const spawn = useCallback((clientX: number, clientY: number, gained: number, crit: boolean) => {
    const root = stageRef.current;
    if (!root) return;
    const rect = root.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    const reduced = prefersReduced();
    const count = reduced ? 2 : crit ? 10 : 6;
    const born = performance.now();
    const next: Particle[] = [];
    for (let i = 0; i < count; i++) {
      const ang = Math.random() * Math.PI * 2;
      const dist = 70 + Math.random() * (crit ? 160 : 110);
      next.push({
        id: pid++,
        x,
        y,
        dx: Math.cos(ang) * dist,
        dy: Math.sin(ang) * dist - 30,
        rot: Math.random() * 720 - 360,
        spin: 0,
        scale: 0.7 + Math.random() * 0.5,
        born,
        life: 0.85,
      });
    }
    setParticles((p) => [...p.slice(-28), ...next]);
    setFloaters((f) => [
      ...f.slice(-10),
      {
        id: pid++,
        x,
        y,
        text: `+${fmt(gained)}`,
        born,
        crit,
      },
    ]);
    window.setTimeout(() => {
      setParticles((p) => p.filter((q) => q.born !== born));
      setFloaters((f) => f.filter((q) => q.born !== born));
    }, 900);
  }, []);

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    e.preventDefault();
    unlockAudio();
    const res = tap();
    if (!res) return;
    if (res.empty) {
      playEmpty();
      setEmptyPulse(true);
      window.setTimeout(() => setEmptyPulse(false), 280);
      trauma.current = Math.min(1, trauma.current + 0.22);
      return;
    }
    playTap(res.crit);
    trauma.current = Math.min(1, trauma.current + (res.crit ? 0.62 : 0.3));
    setAwake(true);
    window.clearTimeout(awakeTimer.current);
    awakeTimer.current = window.setTimeout(() => setAwake(false), 340);
    spawn(e.clientX, e.clientY, res.gained, res.crit);
  };

  const ratio = maxEnergy > 0 ? energy / maxEnergy : 0;

  return (
    <div
      ref={stageRef}
      className="relative min-h-0 flex-1 touch-none select-none"
      onPointerDown={onPointerDown}
      role="button"
      tabIndex={0}
      aria-label="Тапнуть Сашку"
      onKeyDown={(e) => {
        if (e.key === " " || e.key === "Enter") {
          e.preventDefault();
          const r = stageRef.current?.getBoundingClientRect();
          if (!r) return;
          onPointerDown({
            pointerType: "mouse",
            button: 0,
            preventDefault: () => {},
            clientX: r.left + r.width / 2,
            clientY: r.top + r.height / 2,
          } as React.PointerEvent<HTMLDivElement>);
        }
      }}
    >
      <div className="absolute inset-0 overflow-hidden">
        <img src="/game/warehouse.jpg" alt="" className="size-full object-cover object-center" />
        <div className="absolute inset-0 bg-gradient-to-b from-bg/50 via-transparent to-bg/80" />
      </div>

      <div className="absolute inset-0 flex items-center justify-center">
        <div className={cn("relative h-[78%] max-h-[520px] w-[min(86%,420px)]", awake && "sasha-press")}>
          <img
            src="/game/sasha-sleep.webp"
            alt=""
            draggable={false}
            className={cn(
              "absolute inset-0 m-auto h-full w-full object-contain drop-shadow-[0_16px_40px_rgba(0,0,0,0.5)] transition-[opacity,filter] duration-200",
              awake ? "opacity-0" : "opacity-100",
            )}
          />
          <img
            src="/game/sasha-awake.webp"
            alt=""
            draggable={false}
            className={cn(
              "absolute inset-0 m-auto h-full w-full object-contain drop-shadow-[0_0_28px_rgba(232,185,35,0.28)] transition-[opacity,filter] duration-200",
              awake ? "opacity-100 brightness-110" : "opacity-0",
            )}
          />
          {!awake ? (
            <div className="pointer-events-none absolute right-[18%] top-[8%] font-display text-lg font-semibold text-gold/70" aria-hidden>
              <span className="zzz zzz-1">z</span>
              <span className="zzz zzz-2">z</span>
              <span className="zzz zzz-3">z</span>
            </div>
          ) : null}
        </div>
      </div>

      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        {particles.map((p) => (
          <img
            key={p.id}
            src="/game/bar.webp"
            alt=""
            className="particle-bar absolute left-0 top-0 h-10 w-auto"
            style={{
              left: p.x,
              top: p.y,
              ["--dx" as string]: `${p.dx}px`,
              ["--dy" as string]: `${p.dy}px`,
              ["--rot" as string]: `${p.rot}deg`,
              ["--sc" as string]: String(p.scale),
            }}
          />
        ))}
        {floaters.map((f) => (
          <div
            key={f.id}
            className={cn(
              "float-text absolute font-display text-xl font-semibold tabular-nums",
              f.crit ? "text-gold text-[1.45rem]" : "text-fg",
            )}
            style={{ left: f.x, top: f.y }}
          >
            {f.crit ? "крит " : ""}
            {f.text}
          </div>
        ))}
      </div>

      <div className="absolute inset-x-0 bottom-3 px-5">
        <div className={cn("mx-auto max-w-sm", emptyPulse && "energy-shake")}>
          <div className="mb-1 flex items-center justify-between text-xs font-medium text-muted">
            <span>Энергия</span>
            <span className="tabular-nums text-fg">
              {Math.floor(energy)} / {maxEnergy}
            </span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-elevated ring-1 ring-border">
            <div
              className="h-full rounded-full bg-gold transition-[width] duration-150 ease-out"
              style={{ width: `${Math.max(0, Math.min(100, ratio * 100))}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
