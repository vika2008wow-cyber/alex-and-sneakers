export type TabId = "shop" | "ach" | "top" | "me" | null;

export type GameState = {
  version: number;
  bars: number;
  totalBars: number;
  taps: number;
  perTap: number;
  perSec: number;
  clickLevel: number;
  autoLevel: number;
  energyLevel: number;
  regenLevel: number;
  luckLevel: number;
  multiplier: number;
  energy: number;
  maxEnergy: number;
  energyRegen: number;
  claimedRewards: string[];
  achievements: string[];
  goldenSnickers: boolean;
  name: string;
  startedAt: number;
  muted: boolean;
  lastTick: number;
  seenIntro: boolean;
};

export type Particle = {
  id: number;
  x: number;
  y: number;
  dx: number;
  dy: number;
  rot: number;
  spin: number;
  scale: number;
  born: number;
  life: number;
};

export type Floater = {
  id: number;
  x: number;
  y: number;
  text: string;
  born: number;
  crit: boolean;
};

export type PendingReward = {
  id: string;
  icon: "medal" | "trophy" | "crown" | "spark" | "gem" | "rocket";
  title: string;
  text: string;
};
