const nf = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 0 });

export function fmt(n: number): string {
  if (!Number.isFinite(n)) return "0";
  const abs = Math.abs(n);
  if (abs >= 1e12) return (n / 1e12).toFixed(2).replace(".", ",") + " трлн";
  if (abs >= 1e9) return (n / 1e9).toFixed(2).replace(".", ",") + " млрд";
  if (abs >= 1e6) return (n / 1e6).toFixed(2).replace(".", ",") + " млн";
  if (abs >= 1e4) return (n / 1e3).toFixed(1).replace(".", ",") + " тыс";
  return nf.format(Math.floor(n));
}

export function fmtExact(n: number): string {
  return nf.format(Math.floor(n));
}

export function playTime(startedAt: number, now = Date.now()): string {
  const sec = Math.max(0, Math.floor((now - startedAt) / 1000));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  if (h > 0) return `${h} ч ${m} мин`;
  if (m > 0) return `${m} мин`;
  return `${sec} сек`;
}
