import { create } from "zustand";
import { ACHIEVEMENTS, DEFAULT_STATE, REWARDS, SAVE_KEY, SAVE_VERSION, SHOP } from "./constants";
import type { GameState, PendingReward, TabId } from "./types";

type Runtime = {
  hydrated: boolean;
  tab: TabId;
  pendingReward: PendingReward | null;
  combo: number;
  lastTapAt: number;
  awakeUntil: number;
  trauma: number;
  energyFlash: number;
  offlineGain: number;
};

type Actions = {
  hydrate: () => void;
  persist: () => void;
  tick: (dt: number, now: number) => void;
  tap: () => { gained: number; crit: boolean; empty: boolean } | null;
  buy: (id: string) => boolean;
  claimReward: () => void;
  setTab: (tab: TabId) => void;
  setName: (name: string) => void;
  setMuted: (muted: boolean) => void;
  dismissIntro: () => void;
  reset: () => void;
  decayCombo: (now: number) => void;
};

export type Store = GameState & Runtime & Actions;

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}

function migrate(raw: Partial<GameState>): GameState {
  const merged: GameState = { ...DEFAULT_STATE, ...raw, version: SAVE_VERSION };
  merged.bars = Math.max(0, merged.bars || 0);
  merged.totalBars = Math.max(merged.bars, merged.totalBars || 0);
  merged.energy = clamp(merged.energy || DEFAULT_STATE.energy, 0, merged.maxEnergy || DEFAULT_STATE.maxEnergy);
  merged.claimedRewards = Array.isArray(merged.claimedRewards) ? merged.claimedRewards : [];
  merged.achievements = Array.isArray(merged.achievements) ? merged.achievements : [];
  merged.name = (merged.name || "Сашка").slice(0, 18);
  return merged;
}

function loadRaw(): GameState {
  if (typeof window === "undefined") return { ...DEFAULT_STATE };
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return { ...DEFAULT_STATE };
    return migrate(JSON.parse(raw) as Partial<GameState>);
  } catch {
    return { ...DEFAULT_STATE };
  }
}

function saveRaw(s: GameState) {
  if (typeof window === "undefined") return;
  const payload: GameState = {
    version: SAVE_VERSION,
    bars: s.bars,
    totalBars: s.totalBars,
    taps: s.taps,
    perTap: s.perTap,
    perSec: s.perSec,
    clickLevel: s.clickLevel,
    autoLevel: s.autoLevel,
    energyLevel: s.energyLevel,
    regenLevel: s.regenLevel,
    luckLevel: s.luckLevel,
    multiplier: s.multiplier,
    energy: s.energy,
    maxEnergy: s.maxEnergy,
    energyRegen: s.energyRegen,
    claimedRewards: s.claimedRewards,
    achievements: s.achievements,
    goldenSnickers: s.goldenSnickers,
    name: s.name,
    startedAt: s.startedAt,
    muted: s.muted,
    lastTick: s.lastTick,
    seenIntro: s.seenIntro,
  };
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(payload));
  } catch {
    /* quota / private mode */
  }
}

let saveTimer: ReturnType<typeof setTimeout> | null = null;
function scheduleSave(s: GameState) {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    saveRaw(s);
  }, 400);
}

function unlockAchievements(s: GameState): string[] {
  const have = new Set(s.achievements);
  let changed = false;
  for (const a of ACHIEVEMENTS) {
    if (!have.has(a.id) && a.cond(s)) {
      have.add(a.id);
      changed = true;
    }
  }
  return changed ? [...have] : s.achievements;
}

function nextReward(s: GameState): PendingReward | null {
  for (const r of REWARDS) {
    if (s.totalBars >= r.at && !s.claimedRewards.includes(r.id)) {
      return { id: r.id, icon: r.icon, title: r.title, text: r.text };
    }
  }
  return null;
}

export const useGame = create<Store>((set, get) => ({
  ...DEFAULT_STATE,
  hydrated: false,
  tab: null,
  pendingReward: null,
  combo: 0,
  lastTapAt: 0,
  awakeUntil: 0,
  trauma: 0,
  energyFlash: 0,
  offlineGain: 0,

  hydrate: () => {
    if (get().hydrated) return;
    const loaded = loadRaw();
    const now = Date.now();
    if (get().seenIntro && !loaded.seenIntro) {
      const startedAt = get().startedAt || now;
      set({ hydrated: true, startedAt, lastTick: now });
      saveRaw({ ...get(), seenIntro: true, startedAt, lastTick: now });
      return;
    }
    let offlineGain = 0;
    let energy = loaded.energy;
    let bars = loaded.bars;
    let totalBars = loaded.totalBars;
    if (loaded.lastTick > 0 && loaded.seenIntro) {
      const elapsed = clamp((now - loaded.lastTick) / 1000, 0, 8 * 3600);
      offlineGain = loaded.perSec * elapsed;
      bars += offlineGain;
      totalBars += offlineGain;
      energy = clamp(loaded.energy + loaded.energyRegen * elapsed, 0, loaded.maxEnergy);
    }
    const startedAt = loaded.startedAt || now;
    const next: GameState = {
      ...loaded,
      bars,
      totalBars,
      energy,
      startedAt,
      lastTick: now,
    };
    next.achievements = unlockAchievements(next);
    set({
      ...next,
      hydrated: true,
      pendingReward: nextReward(next),
      offlineGain,
      combo: 0,
      trauma: 0,
    });
    saveRaw(next);
  },

  persist: () => {
    const s = get();
    saveRaw({ ...s, lastTick: Date.now() });
  },

  tick: (dt, now) => {
    const s = get();
    if (!s.hydrated || !s.seenIntro) return;
    const capped = Math.min(dt, 0.1);
    const barsGain = s.perSec * capped;
    const energyGain = s.energyRegen * capped;
    const trauma = Math.max(0, s.trauma - capped * 3.2);
    const energyFlash = Math.max(0, s.energyFlash - capped);
    set({
      bars: s.bars + barsGain,
      totalBars: s.totalBars + barsGain,
      energy: clamp(s.energy + energyGain, 0, s.maxEnergy),
      lastTick: now,
      trauma,
      energyFlash,
    });
  },

  decayCombo: (now) => {
    const s = get();
    if (s.combo > 0 && now - s.lastTapAt > 420) set({ combo: 0 });
  },

  tap: () => {
    const s = get();
    if (!s.hydrated || !s.seenIntro) return null;
    if (s.energy < 1) {
      set({ energyFlash: 0.35, trauma: Math.min(1, s.trauma + 0.25) });
      return { gained: 0, crit: false, empty: true };
    }
    const now = Date.now();
    const combo = now - s.lastTapAt < 380 ? s.combo + 1 : 1;
    const critChance = 0.04 + s.luckLevel * 0.04;
    const crit = Math.random() < critChance;
    const comboBonus = 1 + Math.floor(combo / 12) * 0.15;
    const gained = s.perTap * s.multiplier * comboBonus * (crit ? 10 : 1);
    let next: GameState = {
      ...s,
      bars: s.bars + gained,
      totalBars: s.totalBars + gained,
      taps: s.taps + 1,
      energy: s.energy - 1,
      lastTick: now,
    };
    next.achievements = unlockAchievements(next);
    const pending = s.pendingReward ?? nextReward(next);
    set({
      ...next,
      combo,
      lastTapAt: now,
      awakeUntil: now + 320,
      trauma: Math.min(1, s.trauma + (crit ? 0.55 : 0.28)),
      pendingReward: pending,
    });
    scheduleSave(next);
    return { gained, crit, empty: false };
  },

  buy: (id) => {
    const s = get();
    const item = SHOP.find((x) => x.id === id);
    if (!item) return false;
    const cost = item.cost(s);
    if (s.bars < cost) return false;
    const patch = item.buy(s);
    let next: GameState = { ...s, ...patch, bars: s.bars - cost, lastTick: Date.now() };
    next.achievements = unlockAchievements(next);
    set({ ...next, pendingReward: s.pendingReward ?? nextReward(next) });
    saveRaw(next);
    return true;
  },

  claimReward: () => {
    const s = get();
    if (!s.pendingReward) return;
    const def = REWARDS.find((r) => r.id === s.pendingReward!.id);
    if (!def) {
      set({ pendingReward: null });
      return;
    }
    const patch = def.apply(s);
    let next: GameState = {
      ...s,
      ...patch,
      claimedRewards: [...s.claimedRewards, def.id],
    };
    next.achievements = unlockAchievements(next);
    set({ ...next, pendingReward: nextReward(next) });
    saveRaw(next);
  },

  setTab: (tab) => set({ tab }),
  setName: (name) => {
    const n = name.slice(0, 18);
    set({ name: n });
    scheduleSave({ ...get(), name: n });
  },
  setMuted: (muted) => {
    set({ muted });
    scheduleSave({ ...get(), muted });
  },
  dismissIntro: () => {
    const now = Date.now();
    const s = get();
    const next = {
      ...s,
      seenIntro: true,
      startedAt: s.startedAt || now,
      lastTick: now,
    };
    set(next);
    saveRaw(next);
  },
  reset: () => {
    const next = { ...DEFAULT_STATE, startedAt: Date.now(), lastTick: Date.now(), seenIntro: true };
    set({
      ...next,
      hydrated: true,
      tab: null,
      pendingReward: null,
      combo: 0,
      lastTapAt: 0,
      awakeUntil: 0,
      trauma: 0,
      energyFlash: 0,
      offlineGain: 0,
    });
    saveRaw(next);
  },
}));
