import type { GameState, PendingReward } from "./types";

export const SAVE_KEY = "sashka_snickers_save_v1";
export const SAVE_VERSION = 1;

export const DEFAULT_STATE: GameState = {
  version: SAVE_VERSION,
  bars: 0,
  totalBars: 0,
  taps: 0,
  perTap: 1,
  perSec: 0,
  clickLevel: 1,
  autoLevel: 0,
  energyLevel: 0,
  regenLevel: 0,
  luckLevel: 0,
  multiplier: 1,
  energy: 600,
  maxEnergy: 600,
  energyRegen: 3,
  claimedRewards: [],
  achievements: [],
  goldenSnickers: false,
  name: "Сашка",
  startedAt: 0,
  muted: false,
  lastTick: 0,
  seenIntro: false,
};

export type ShopItem = {
  id: string;
  name: string;
  desc: string;
  icon: "pointer" | "bot" | "zap" | "battery" | "heart" | "clover";
  cost: (s: GameState) => number;
  owned: (s: GameState) => number;
  buy: (s: GameState) => Partial<GameState>;
};

export const SHOP: ShopItem[] = [
  {
    id: "click",
    name: "Сила тапа",
    desc: "+1 сникерс за нажатие",
    icon: "pointer",
    cost: (s) => Math.floor(18 * Math.pow(1.55, s.clickLevel - 1)),
    owned: (s) => s.clickLevel,
    buy: (s) => ({ clickLevel: s.clickLevel + 1, perTap: s.perTap + 1 }),
  },
  {
    id: "auto",
    name: "Работники склада",
    desc: "+1 сникерс в секунду, пока Сашка спит",
    icon: "bot",
    cost: (s) => Math.floor(55 * Math.pow(1.62, s.autoLevel)),
    owned: (s) => s.autoLevel,
    buy: (s) => ({ autoLevel: s.autoLevel + 1, perSec: s.perSec + 1 }),
  },
  {
    id: "boost",
    name: "Мегабуст",
    desc: "Удвоить силу тапа навсегда",
    icon: "zap",
    cost: (s) => Math.floor(420 * s.multiplier * (1 + Math.log2(s.multiplier) * 1.4)),
    owned: (s) => Math.round(Math.log2(s.multiplier)),
    buy: (s) => ({ multiplier: s.multiplier * 2 }),
  },
  {
    id: "energy",
    name: "Запас сил",
    desc: "+200 к запасу энергии",
    icon: "battery",
    cost: (s) => Math.floor(80 * Math.pow(1.7, s.energyLevel)),
    owned: (s) => s.energyLevel,
    buy: (s) => ({
      energyLevel: s.energyLevel + 1,
      maxEnergy: s.maxEnergy + 200,
      energy: s.energy + 200,
    }),
  },
  {
    id: "regen",
    name: "Сон силача",
    desc: "+1 энергия в секунду",
    icon: "heart",
    cost: (s) => Math.floor(90 * Math.pow(1.68, s.regenLevel)),
    owned: (s) => s.regenLevel,
    buy: (s) => ({
      regenLevel: s.regenLevel + 1,
      energyRegen: s.energyRegen + 1,
    }),
  },
  {
    id: "luck",
    name: "Золотой укус",
    desc: "+4% шанс критического тапа ×10",
    icon: "clover",
    cost: (s) => Math.floor(220 * Math.pow(1.75, s.luckLevel)),
    owned: (s) => s.luckLevel,
    buy: (s) => ({ luckLevel: s.luckLevel + 1 }),
  },
];

export type RewardDef = {
  id: string;
  at: number;
  icon: PendingReward["icon"];
  title: string;
  text: string;
  apply: (s: GameState) => Partial<GameState>;
};

export const REWARDS: RewardDef[] = [
  {
    id: "r100",
    at: 100,
    icon: "medal",
    title: "Бронзовый батончик",
    text: "+500 сникерсов на склад.",
    apply: (s) => ({ bars: s.bars + 500, totalBars: s.totalBars + 500 }),
  },
  {
    id: "r1k",
    at: 1000,
    icon: "medal",
    title: "Серебряный батончик",
    text: "Работники склада: +2 сникерса в секунду.",
    apply: (s) => ({ perSec: s.perSec + 2, autoLevel: s.autoLevel + 2 }),
  },
  {
    id: "r10k",
    at: 10000,
    icon: "trophy",
    title: "Золотой батончик",
    text: "Множитель тапа ×3 и +5 000 сникерсов.",
    apply: (s) => ({
      multiplier: s.multiplier * 3,
      bars: s.bars + 5000,
      totalBars: s.totalBars + 5000,
    }),
  },
  {
    id: "r100k",
    at: 100000,
    icon: "gem",
    title: "Золотой сникерс",
    text: "Автоклик +20/сек и сила тапа ×5.",
    apply: (s) => ({
      goldenSnickers: true,
      perSec: s.perSec + 20,
      autoLevel: s.autoLevel + 20,
      multiplier: s.multiplier * 5,
    }),
  },
  {
    id: "r500k",
    at: 500000,
    icon: "crown",
    title: "Король склада",
    text: "+100 000 сникерсов бонусом.",
    apply: (s) => ({ bars: s.bars + 100000, totalBars: s.totalBars + 100000 }),
  },
  {
    id: "r1m",
    at: 1000000,
    icon: "rocket",
    title: "Миллионер склада",
    text: "Нереально. Множитель тапа ×10.",
    apply: (s) => ({ multiplier: s.multiplier * 10 }),
  },
];

export type AchievementDef = {
  id: string;
  icon: "pointer" | "flame" | "zap" | "gem" | "trophy" | "store" | "bot" | "crown";
  title: string;
  desc: string;
  cond: (s: GameState) => boolean;
};

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: "first", icon: "pointer", title: "Первый тап", desc: "Разбудить Сашку", cond: (s) => s.taps >= 1 },
  { id: "tap100", icon: "flame", title: "Разогрев", desc: "100 тапов", cond: (s) => s.taps >= 100 },
  { id: "bar1k", icon: "zap", title: "Тысяча", desc: "1 000 сникерсов за всё время", cond: (s) => s.totalBars >= 1000 },
  { id: "bar10k", icon: "flame", title: "Палета", desc: "10 000 сникерсов за всё время", cond: (s) => s.totalBars >= 10000 },
  { id: "bar100k", icon: "gem", title: "Фура", desc: "100 000 сникерсов за всё время", cond: (s) => s.totalBars >= 100000 },
  { id: "golden", icon: "trophy", title: "Золотой сникерс", desc: "Получить легендарную награду", cond: (s) => s.goldenSnickers },
  { id: "shop", icon: "store", title: "Закупщик", desc: "Сила тапа 5 уровня", cond: (s) => s.clickLevel >= 5 },
  { id: "auto", icon: "bot", title: "Автоматизация", desc: "5 работников на складе", cond: (s) => s.autoLevel >= 5 },
  { id: "king", icon: "crown", title: "Хозяин склада", desc: "1 000 000 сникерсов за всё время", cond: (s) => s.totalBars >= 1_000_000 },
];

export const BOT_NAMES = [
  "БорисСклад",
  "КатяТап",
  "ВоваГолд",
  "НастяПалета",
  "ОлегФура",
  "ЛенаКарамель",
  "МаксНуга",
  "ИгорьАрахис",
  "ЮляЛампа",
  "ПашаПоток",
  "ДашаШоколад",
  "КириллСейф",
];
