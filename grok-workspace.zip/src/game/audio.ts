let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let sfx: GainNode | null = null;
let noise: AudioBuffer | null = null;
let muted = false;

function ensure(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC({ latencyHint: "interactive" });
    master = ctx.createGain();
    sfx = ctx.createGain();
    sfx.gain.value = 0.7;
    master.gain.value = muted ? 0 : 0.9;
    sfx.connect(master);
    master.connect(ctx.destination);
    const n = ctx.createBuffer(1, ctx.sampleRate * 0.4, ctx.sampleRate);
    const d = n.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    noise = n;
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

export function unlockAudio() {
  ensure();
}

export function setMuted(next: boolean) {
  muted = next;
  if (master && ctx) {
    master.gain.setTargetAtTime(next ? 0 : 0.9, ctx.currentTime, 0.02);
  }
}

function envGain(c: AudioContext, peak: number, dur: number) {
  const g = c.createGain();
  const t = c.currentTime;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(peak, t + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  g.connect(sfx!);
  return g;
}

export function playTap(crit = false) {
  const c = ensure();
  if (!c || muted || !sfx || !noise) return;
  const t = c.currentTime;
  const osc = c.createOscillator();
  const g = envGain(c, crit ? 0.22 : 0.12, crit ? 0.18 : 0.09);
  osc.type = "triangle";
  const f = (crit ? 240 : 170) + Math.random() * 50;
  osc.frequency.setValueAtTime(f, t);
  osc.frequency.exponentialRampToValueAtTime(crit ? 90 : 70, t + 0.1);
  osc.connect(g);
  osc.start(t);
  osc.stop(t + 0.14);

  const src = c.createBufferSource();
  src.buffer = noise;
  src.playbackRate.value = 3.2 + Math.random() * 0.8;
  const ng = envGain(c, crit ? 0.08 : 0.035, 0.06);
  const bp = c.createBiquadFilter();
  bp.type = "bandpass";
  bp.frequency.value = crit ? 1800 : 900;
  src.connect(bp).connect(ng);
  src.start(t);
  src.stop(t + 0.07);
}

export function playEmpty() {
  const c = ensure();
  if (!c || muted || !sfx) return;
  const t = c.currentTime;
  const osc = c.createOscillator();
  const g = envGain(c, 0.06, 0.08);
  osc.type = "square";
  osc.frequency.setValueAtTime(90, t);
  osc.frequency.exponentialRampToValueAtTime(50, t + 0.08);
  osc.connect(g);
  osc.start(t);
  osc.stop(t + 0.09);
}

export function playBuy() {
  const c = ensure();
  if (!c || muted || !sfx) return;
  const t = c.currentTime;
  [523, 659, 784].forEach((f, i) => {
    const osc = c.createOscillator();
    const g = c.createGain();
    const when = t + i * 0.05;
    osc.type = "sine";
    osc.frequency.value = f;
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(0.09, when + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, when + 0.18);
    osc.connect(g).connect(sfx!);
    osc.start(when);
    osc.stop(when + 0.2);
  });
}

export function playReward() {
  const c = ensure();
  if (!c || muted || !sfx) return;
  const t = c.currentTime;
  [392, 523, 659, 784, 1046].forEach((f, i) => {
    const osc = c.createOscillator();
    const g = c.createGain();
    const when = t + i * 0.07;
    osc.type = "triangle";
    osc.frequency.value = f;
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(0.11, when + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, when + 0.28);
    osc.connect(g).connect(sfx!);
    osc.start(when);
    osc.stop(when + 0.3);
  });
}
